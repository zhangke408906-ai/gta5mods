#!/usr/bin/env node
/**
 * GTA5 模组库 —— 独立部署版（不需要 DSH，一台免费的 Node 主机就能跑）
 *
 * 和 DSH 插件版的区别：
 *   · 没有「下载到本机 / 导入 / 我的」这些功能（那是给手机主人用的）
 *   · 所有下载都是**给访问者自己的**：能直连的站点直接 302 到它的 CDN，
 *     乐城那种带 IP 绑定 token 的才由本服务代下转发
 *   · 出站访问三个模组站 + 可选的 Agnes 翻译（配了 AGNES_CREDENTIAL 才启用）
 *
 * 环境变量：
 *   PORT               监听端口（默认 7860，Hugging Face Spaces 的约定端口）
 *   GTA5_TOKEN         可选：设了就要求 /mods?k=<token>，不设则对所有人开放
 *   AGNES_CREDENTIAL   可选：配了才会真正调模型翻译（否则只有术语表中文化）
 *   AGNES_BASE_URL / AGNES_MODEL  可选：默认 apihub.agnes-ai.cn 的 agnes-3.0-flash
 *   MAX_DOWNLOADS      可选：同时代下的并发上限（默认 3）
 */

import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sourceList, getSource, defaultSource } from './lib/sources/index.mjs';
import { localizeItem, translateText } from './lib/translate.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT ?? 7860);
const TOKEN = process.env.GTA5_TOKEN ?? '';
const MAX_DOWNLOADS = Number(process.env.MAX_DOWNLOADS ?? 3);
const COOKIE = 'gta5pub';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
};

const json = (res, body, status = 200, extra = {}) => {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...extra });
  res.end(JSON.stringify(body));
};
const text = (res, body, status = 200) => {
  res.writeHead(status, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
  res.end(body);
};

const cookies = (header = '') => Object.fromEntries(String(header).split(';').map((p) => p.trim()).filter(Boolean).map((p) => {
  const i = p.indexOf('=');
  return [p.slice(0, i), p.slice(i + 1)];
}));

/* ------------------------------------------------------------------ 限流 */

const rate = new Map();
const ipOf = (req) => String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '?').split(',')[0].trim();

function limited(ip, kind) {
  const now = Date.now();
  let row = rate.get(ip);
  if (!row || now > row.at + 60_000) { row = { at: now, req: 0, tr: 0 }; rate.set(ip, row); }
  row.req++;
  if (row.req > 150) return 'rate';
  if (kind === 'translate') {
    row.tr++;
    if (row.tr > 20) return 'translate-rate';
  }
  if (rate.size > 800) rate.clear();
  return null;
}

/* ------------------------------------------------------------------ 列表缓存 */

const listCache = new Map();
const LIST_TTL = 5 * 60 * 1000;
async function getPage(sourceId, target) {
  const key = `${sourceId}|${target}`;
  const hit = listCache.get(key);
  if (hit && Date.now() - hit.at < LIST_TTL) return hit.value;
  const adapter = getSource(sourceId);
  const res = await fetch(target, { headers: { 'user-agent': 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const value = adapter.parseList(await res.text(), target);
  listCache.set(key, { at: Date.now(), value });
  if (listCache.size > 200) listCache.delete(listCache.keys().next().value);
  return value;
}

/* ------------------------------------------------------------------ 静态 */

async function serveStatic(req, res, rel) {
  const file = join(HERE, 'lib', rel);
  if (!file.startsWith(HERE)) return false;
  try {
    const body = await readFile(file);
    res.writeHead(200, { 'content-type': MIME[extname(file)] ?? 'application/octet-stream', 'cache-control': 'public, max-age=86400' });
    res.end(body);
    return true;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ 对外下载 */

let activeDownloads = 0;

async function publicDownload(req, res, url) {
  if (activeDownloads >= MAX_DOWNLOADS) return text(res, '同时下载的人有点多，等十几秒再点一次。', 429);
  activeDownloads++;
  try {
    const adapter = getSource(url.searchParams.get('source') ?? '');
    const detailUrl = url.searchParams.get('u') ?? '';
    const index = Number(url.searchParams.get('file') ?? 0);
    if (!detailUrl) throw new Error('缺少 u 参数');

    const detail = await adapter.detail(detailUrl);
    const file = detail.files[index] ?? detail.files[0];
    if (!file) throw new Error('这个模组没有可下载的文件');

    const resolved = await adapter.resolveDownload(detailUrl, file, () => {});
    const host = new URL(resolved.url).host;
    if (!/libertycity\.(net|ru|com)$/i.test(host)) {
      // 公共 CDN：让访问者自己下，服务器不带宽
      res.writeHead(302, { location: resolved.url, 'cache-control': 'no-store' });
      res.end();
      return;
    }

    const fileRes = await fetch(resolved.url, {
      headers: { 'user-agent': 'Mozilla/5.0 (Linux; Android 14) Chrome/124 Mobile', referer: resolved.referer ?? detailUrl, accept: '*/*' },
      redirect: 'follow',
    });
    if (!fileRes.ok || !fileRes.body) throw new Error(`文件服务器返回 ${fileRes.status}`);
    const name = resolved.name || 'mod.zip';
    res.writeHead(200, {
      'content-type': 'application/octet-stream',
      'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}`,
      ...(fileRes.headers.get('content-length') ? { 'content-length': fileRes.headers.get('content-length') } : {}),
      'cache-control': 'no-store',
    });
    await pipeline(fileRes.body, res);
  } catch (error) {
    if (!res.headersSent) {
      const message = String(error?.message ?? error);
      // 站点拦机房 IP（或拿不到挑战）：直接跳原页面，让访问者用自己的 IP 去下
      if (/40[13]|429|503|ECONN|timeout/i.test(message)) {
        res.writeHead(302, { location: detailUrl, 'cache-control': 'no-store' });
        res.end();
        return;
      }
      text(res, `下载失败：${message}`, 502);
    } else res.destroy();
  } finally {
    activeDownloads--;
  }
}

/* ------------------------------------------------------------------ 主服务 */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const path = url.pathname;
  const ip = ipOf(req);

  // 可选口令
  if (TOKEN) {
    const authed = url.searchParams.get('k') === TOKEN || cookies(req.headers.cookie)[COOKIE] === TOKEN;
    if (!authed) {
      res.writeHead(401, { 'content-type': 'text/html; charset=utf-8' });
      res.end('<!doctype html><meta charset="utf-8"><body style="background:#0b0e14;color:#8b97ab;font:15px system-ui;display:grid;place-items:center;height:100vh;margin:0"><div>需要访问口令：请使用完整链接</div></body>');
      return;
    }
    if (url.searchParams.get('k') === TOKEN) {
      const clean = new URL(url.href);
      clean.searchParams.delete('k');
      res.writeHead(302, { 'set-cookie': `${COOKIE}=${TOKEN}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`, location: clean.pathname + (clean.search || '') });
      res.end();
      return;
    }
  }

  const blocked = limited(ip, path === '/api/gta5/translate' ? 'translate' : 'normal');
  if (blocked) return text(res, blocked === 'rate' ? '请求太频繁，休息一下。' : '翻译次数用完了，过一分钟再试。', 429);

  try {
    if (path === '/' ) {
      res.writeHead(302, { location: '/mods' });
      res.end();
      return;
    }
    if (path === '/healthz') return text(res, 'ok');
    if (path === '/mods' || path === '/mods/') {
      const html = await readFile(join(HERE, 'lib', 'app.html'), 'utf8');
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      res.end(html.replace('</head>', '<script>window.__PUBLIC_MODE__=true;</script></head>'));
      return;
    }
    if (path.startsWith('/mods/')) {
      if (await serveStatic(req, res, path.replace(/^\/mods\//, ''))) return;
      return text(res, '404', 404);
    }

    if (path === '/api/gta5/sources') return json(res, { sources: sourceList(), defaultSource });
    if (path === '/api/gta5/list') {
      const sourceId = url.searchParams.get('source') || defaultSource;
      const adapter = getSource(sourceId);
      const target = adapter.listUrl({
        path: url.searchParams.get('path') || adapter.categories[0]?.path || '/',
        page: Number(url.searchParams.get('page') || '1'),
        q: (url.searchParams.get('q') || '').trim(),
      });
      const data = await getPage(sourceId, target);
      const items = sourceId === 'libertycity' ? data.items : data.items.map(localizeItem);
      return json(res, { source: sourceId, page: data.page, pages: data.pages, hasMore: data.hasMore ?? data.page < data.pages, items, target });
    }
    if (path === '/api/gta5/detail') {
      const sourceId = url.searchParams.get('source') || defaultSource;
      const target = url.searchParams.get('u');
      if (!target) return json(res, { error: '缺少 u 参数' }, 400);
      const adapter = getSource(sourceId);
      try {
        const detail = await adapter.detail(target);
        const needTranslate = sourceId !== 'libertycity' && /[A-Za-z]/.test(detail.title ?? '');
        return json(res, { detail: { ...detail, needTranslate } });
      } catch (error) {
        // 机房 IP 被站点拦（403/429/503）时不要让界面只显示一行报错：
        // 给一个「空详情」，前端会保留「原页面」按钮，访问者可以自己去站内下。
        const message = String(error?.message ?? error);
        const blocked = /40[13]|429|503|ECONN|timeout/i.test(message);
        const slug = decodeURIComponent(target.split('/').filter(Boolean).pop() ?? '模组');
        return json(res, {
          detail: {
            source: sourceId, id: '', title: slug, url: target,
            cover: '', thumbs: [], images: [],
            description: '', descriptionText: blocked
              ? '这个站点限制了机房 IP 的访问，详情打不开。点下面的「原页面」可以直接在浏览器里打开并下载。'
              : `详情加载失败：${message}`,
            category: '', breadcrumbs: [], author: '', date: '', fileSize: '',
            rating: '', ratingCount: '', downloads: '', files: [], telegram: '',
            blocked,
          },
          needTranslate: false,
        });
      }
    }
    if (path === '/api/gta5/img') {
      const target = url.searchParams.get('u');
      if (!target) return json(res, { error: '缺少 u 参数' }, 400);
      const upstream = await fetch(target, { headers: { 'user-agent': 'Mozilla/5.0 (Linux; Android 14) Chrome/124 Mobile', referer: new URL(target).origin + '/' } });
      if (!upstream.ok) return json(res, { error: `图片 ${upstream.status}` }, 502);
      const buf = Buffer.from(await upstream.arrayBuffer());
      res.writeHead(200, { 'content-type': upstream.headers.get('content-type') ?? 'image/jpeg', 'cache-control': 'public, max-age=604800', 'content-length': buf.length });
      res.end(buf);
      return;
    }
    if (path === '/api/gta5/translate' && req.method === 'POST') {
      const chunks = [];
      for await (const chunk of req) chunks.push(chunk);
      let body = {};
      try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* 空 body */ }
      const out = { titleZh: '', descriptionZh: '' };
      if (body.title) out.titleZh = (await translateText(body.title, 'title')) ?? '';
      if (body.text) out.descriptionZh = (await translateText(body.text, 'text')) ?? '';
      return json(res, out);
    }
    if (path === '/api/gta5/public-download') return publicDownload(req, res, url);

    return text(res, '404', 404);
  } catch (error) {
    if (!res.headersSent) text(res, `服务错误：${error?.message ?? error}`, 500);
    else res.destroy();
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[gta5mods] 已启动：http://0.0.0.0:${PORT}/mods  (口令：${TOKEN ? '已开启' : '无，对所有人开放'})`);
});
