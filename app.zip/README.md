# GTA5 模组库（独立部署版）

把三个 GTA 5 模组站聚合成一个中文界面。**不需要 DSH、不需要数据库、不需要存文件**，
一个 Node 进程就能跑，所以能塞进各种免费主机。

| 来源 | 站点 | 下载 |
|---|---|---|
| 乐城 LibertyCity | zh.libertycity.net（中文） | 服务端代下（要过站点 30 秒等待） |
| GTA5-Mods | gta5-mods.com（英文→中文） | 302 跳站点 CDN |
| GTA5mod.net | gta5mod.net（英文→中文） | 302 跳站点 CDN |

## 本地跑

```bash
npm start            # 默认 http://localhost:7860/mods
```

环境变量：

| 变量 | 作用 |
|---|---|
| `PORT` | 监听端口，默认 `7860`（Hugging Face Spaces 的约定端口） |
| `GTA5_TOKEN` | 可选。设了就要求 `?k=<token>`，不设则对所有人开放 |
| `AGNES_CREDENTIAL` | 可选。配了才调模型翻译，不配只有术语表中文化（无需任何 API Key） |
| `AGNES_BASE_URL` / `AGNES_MODEL` | 可选，默认 `https://apihub.agnes-ai.cn/v1` + `agnes-3.0-flash` |
| `MAX_DOWNLOADS` | 同时代下的并发上限，默认 3 |

## 部署到免费主机

### 方案 A：Render 免费 Web Service（推荐，无需信用卡）

1. 把这个目录推到 GitHub（公开仓库即可）
2. Render → **New → Web Service** 选这个仓库，Runtime 选 **Docker**
3. Instance Type 选 **Free**，端口填 `7860`，Deploy
4. 拿到 `https://<name>.onrender.com/mods`

> 免费档限制：15 分钟没人访问会休眠，下一次访问约 1 分钟冷启动；每月 5 GB 流量
> （下载走了站点 CDN，几乎不消耗）。也支持在 Render 里 **New → Blueprint** 直接用
> 仓库里的 `render.yaml`。

### 方案 B：Hugging Face Spaces（免费、不用信用卡、16 GB 内存）

1. huggingface.co → **New Space** → SDK 选 **Docker** → 空白模板
2. 上传这些文件：`server.mjs`、`lib/`、`app.html`、`package.json`、`Dockerfile`
3. 把 `HF-README.md` 的内容存成 Space 里的 `README.md`（那段 YAML 头是 Spaces 的配置）
4. 构建完成后地址是 `https://<user>-<space>.hf.space/mods`

> 免费 CPU Space 长时间没人访问会休眠（约 48 小时），唤醒要几十秒。

### 方案 C：任何 Docker 主机 / VPS

```bash
docker build -t gta5mods .
docker run -d -p 7860:7860 --name gta5mods gta5mods
```

## 结构

```
server.mjs                  HTTP 服务（页面 + 4 个只读接口 + 下载转发）
app.html                    整个前端（内联 CSS/JS）
lib/sources/index.mjs       站点登记表（统一接口 + 通用下载）
lib/sources/gta5mods.mjs    GTA5-Mods 适配器
lib/sources/gta5modnet.mjs  GTA5mod.net 适配器
lib/lc.mjs                  乐城适配器（含 30 秒等待 + JS 挑战还原）
lib/categories.json         乐城分类树
lib/translate.mjs           中文化：术语表（同步）+ 模型翻译（带缓存）
Dockerfile / render.yaml    部署用
HF-README.md                Hugging Face Spaces 的 README（含 YAML 头）
```

## 注意

- 这台服务器上**没有**「下载到本机 / 导入模组 / 我的」——那是手机版才有的功能；
  这里的下载都直接给访问者。
- 三个模组站都在 Cloudflare 后面。机房 IP 偶尔会被拦（403），
  列表/详情会直接报错在界面上，换个平台或等一会儿再试即可。
- 乐城的文件地址带 IP 绑定 token，只能由本服务代下转发；另外两个站直接跳 CDN，
  所以带宽开销极小。
